package com.ssafy.edu.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.edu.dto.UserDto;


@Repository
public class UserDao {
	String ns ="com.ssafy.edu.";
	
	@Autowired
	private SqlSession sqlSession;

	public void insertUser(UserDto dto) {
		sqlSession.insert(ns+"insertUser",dto);
	}

	public void updateUser(UserDto dto) {
		sqlSession.update(ns+"updateUser",dto);
	}

	public void deleteUser(String id) {
		sqlSession.delete(ns+"deleteUser",id);
	}

	public List<UserDto> findAllUsers() {
		return sqlSession.selectList(ns+"findAllUsers");
	}

	public int makeUPK() {
		return sqlSession.selectOne(ns+"makeUPK");
	}

	public UserDto findUserById(String id) {
		return sqlSession.selectOne(ns+"findUserById",id);
	}


}
