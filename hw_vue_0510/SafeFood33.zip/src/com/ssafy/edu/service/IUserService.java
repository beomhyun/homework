package com.ssafy.edu.service;

import java.util.List;

import com.ssafy.edu.dto.UserDto;



public interface IUserService {
	void insertUser(UserDto dto);
	void updateUser(UserDto dto);
	void deleteUser(String id);
	List<UserDto> findAllUsers();
	int makeUPK();
	UserDto findUserById(String id);
	
	
	// 아직 user.xml에 구현 안했어
/*	void insertUser_allergy(int ucode, String allergys);
	String searchUser_allergy(int ucode);*/
}
