package com.ssafy.edu.service;
import java.util.HashMap;
import java.util.List;

import com.ssafy.edu.dto.FoodInfoDto;

public interface IFoodinfoService {
	/*boolean insertFoodInfo(FoodInfoDto dto);
	boolean updateFoodInfo(FoodInfoDto dto);
	boolean deleteFoodInfo(int seq);
	int makeFPK();*/
	
	FoodInfoDto findFoodInfoById(int food_code)throws Exception;
	List<FoodInfoDto> findAllFoods() throws Exception;
	List<FoodInfoDto> searchFood(HashMap<String, String> map) throws Exception;
	String Allergy(int food_code);
}
