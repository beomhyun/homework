package com.ssafy.edu.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.edu.dao.FoodInfoDao;
import com.ssafy.edu.dto.FoodInfoDto;

@Service
public class FoodInfoService implements IFoodinfoService{
	@Autowired
	private FoodInfoDao foodinfoDao;
	
	/*@Override
	public int makeFPK() {
		String sql = " SELECT MAX(food_code) FROM FOODINFO ";
		int result = -1;
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();
			while(rs.next())
				result = rs.getInt(1);
			
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			close(rs,psmt,conn);
		}
		result++;
		return result;
	}*/
	/*@Override
	public boolean insertFoodInfo(FoodInfoDto dto) {
		boolean check = true;
		int food_code = makeFPK();
		String sql = " INSERT INTO FOODINFO(food_code,food_name,food_maker,food_material,food_img) "+
				" VALUE(?,?,?,?,?) ";
		Connection conn = null;
		PreparedStatement psmt = null;
		try {
			conn = getConnection();
			psmt = conn.prepareStatement(sql);
			int i = 1;
			psmt.setInt(i++, food_code);
			psmt.setString(i++, dto.getName());
			psmt.setString(i++, dto.getMaker());
			psmt.setString(i++, dto.getMaterial());
			psmt.setString(i++, dto.getImg());
			int count = psmt.executeUpdate();
			if(count <= 0) {
				check = false;
				throw new SQLException("추가에 실해하셨습니다.");
			}
		} catch (Exception e) {
			check = false;
		}finally {
			close(null,psmt,conn);
		}
		return check;
	}*/
	/*@Override
	public boolean updateFoodInfo(FoodInfoDto dto) {
		String sql = " UPDATE FOODINFO SET FOOD_NAME=?,FOOD_MAKER=?,FOOD_MATERIAL=?,FOOD_IMG=? ";
		Connection conn = null;
		PreparedStatement psmt = null;
		boolean check = true;
		try {
			conn = getConnection();
			psmt = conn.prepareStatement(sql);
			int i = 1;
			psmt.setString(i++, dto.getName());
			psmt.setString(i++, dto.getMaker());
			psmt.setString(i++, dto.getMaterial());
			psmt.setString(i++, dto.getImg());
			int count = psmt.executeUpdate();
			if(count <= 0) {
				check = false;
				throw new SQLException("수정에 실패하였습니다.");
			}
		} catch (Exception e) {
			check = false;
		}finally {
			close(null,psmt,conn);
		}
		return check;
	}*/
	/*@Override
	public boolean deleteFoodInfo(int seq) {
		boolean check = true;
		String sql = " DELETE FROM FOODINFO "+" WHERE FOOD_CODE=? ";
		Connection conn = null;
		PreparedStatement  psmt = null;
		try {
			conn = getConnection();
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, seq);
			int count = psmt.executeUpdate();
			if(count <= 0) {
				check = false;
				throw new SQLException("삭제에 실패하였습니다.");
			}
		} catch (Exception e) {
			check = false;
		}finally {
			close(null,psmt,conn);
		}
		return check;
	}*/
	@Override
	public FoodInfoDto findFoodInfoById(int food_code) {
		return foodinfoDao.getFoodInfoById(food_code);
	}
	@Override
	public List<FoodInfoDto> findAllFoods() throws Exception{
		return foodinfoDao.getFoodInfolist();
	}
	@Override
	public List<FoodInfoDto> searchFood(HashMap<String, String> map) throws Exception{
		return foodinfoDao.searchFood(map);
	}
	public String Allergy(int seq) {
		List<String> list = foodinfoDao.getAllergy(seq);
		String line = "";
		for(String a:list) {
			line+=a+",";
		}
		line = line.substring(0, line.length());
		return line;
	}
}
