package com.ssafy.edu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.edu.dao.UserDao;
import com.ssafy.edu.dto.UserDto;


@Service
public class UserServiceImpl implements IUserService{

	@Autowired
	private UserDao userDao;
	
	
	@Override
	@Transactional
	public void insertUser(UserDto dto) {
		userDao.insertUser(dto);
	}

	@Override
	@Transactional
	public void updateUser(UserDto dto) {
		userDao.updateUser(dto);
	}

	@Override
	@Transactional
	public void deleteUser(String id) {
		userDao.deleteUser(id);
	}

	// 현재 쓰이는 곳은 없음
	@Override
	@Transactional(readOnly=true)
	public List<UserDto> findAllUsers() {
		return userDao.findAllUsers();
	}

	@Override
	@Transactional(readOnly=true)
	public int makeUPK() {
		return userDao.makeUPK();
	}

	@Override
	@Transactional(readOnly=true)
	public UserDto findUserById(String id) {
		return userDao.findUserById(id);
	}
	
}
