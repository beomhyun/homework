package com.ssafy.edu.controller;

import java.util.Date;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.edu.dto.UserDto;
import com.ssafy.edu.service.IUserService;

@Controller
public class UserController {
	private static final Logger logger = 
			LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	private IUserService iUserService;
	
	@RequestMapping(value = "signupbf.do",method=RequestMethod.GET)
	public String signupbf(Model model) throws Exception{
		logger.debug("signupbf!"+new Date());
		int a = iUserService.makeUPK();
		model.addAttribute("pk",a);
		return "signUp";
	}
	
	@RequestMapping(value = "signup.do", 
			method = {RequestMethod.GET,RequestMethod.POST})
	public String signup(int _upk,String _uid,String _upwd,String _uname,String _uaddress,String _uphone,@RequestParam("_uallergy") String[] _uallergy, Model model) throws Exception {
		logger.debug("Welcome UserController signup------------------! "+ new Date());
		StringBuffer sb = new StringBuffer();
		if(_uallergy != null) {
			for (String string : _uallergy) {
				sb.append(string+" ");
			}
		}
		logger.debug(_upk+" "+_uid+" "+_upwd+" "+_uname+" "+_uaddress+" "+_uphone+" "+sb.toString());
		try {
			iUserService.insertUser(new UserDto(_upk,_uid,_upwd,_uname,_uaddress,_uphone,sb.toString()));
			model.addAttribute("stat", "회원가입 성공");
			model.addAttribute("msg", "가입에 성공하였습니다. ");
			model.addAttribute("nurl","./main.do");
		}catch(Exception e){
			logger.debug("Welcome UserController signup fail------------------! "+ new Date());
			model.addAttribute("stat", "회원가입 실패");
			model.addAttribute("msg", "가입에 실패하였습니다. ");
			model.addAttribute("nurl","/index.jsp");
		}
		return "/share/success";
	}//	
	@RequestMapping(value = "main.do", method = RequestMethod.GET)
	public String main(Model model) {
		logger.debug("main!"+new Date());
		return "qna";
	}
	
	@RequestMapping(value = "login.do", 
			method = {RequestMethod.GET,RequestMethod.POST})
	public String login(@ModelAttribute UserDto userdto, Model model, HttpSession session) throws Exception {
		logger.debug("Welcome UserController login------------------! "+ new Date());
		try {
			UserDto logindto = iUserService.findUserById(userdto.getUser_id());
			if(logindto.getUser_pwd().equals(userdto.getUser_pwd())) {
				// 로그인 성공
				session.setAttribute("login", logindto);
				session.setMaxInactiveInterval(10*60);
			}
		}catch(Exception e){
			logger.debug("Welcome UserController login fail------------------! "+ new Date());
		}
		return "main";
	}//
	
	@RequestMapping(value = "logout.do", 
			method = {RequestMethod.GET,RequestMethod.POST})
	public String logout(@ModelAttribute UserDto userdto, Model model, HttpSession session) throws Exception {
		logger.debug("Welcome UserController logout------------------! "+ new Date());
		session.invalidate();
		return "main";
	}//
	
	@RequestMapping(value = "userdetail.do", 
			method = {RequestMethod.GET,RequestMethod.POST})
	public String userdetail(@ModelAttribute String user_id, Model model) throws Exception {
		logger.debug("Welcome UserController userdetail------------------! "+ new Date());
		try {
			model.addAttribute("user", iUserService.findUserById(user_id));
		}catch(Exception e){
			logger.debug("Welcome UserController userdetail fail------------------! "+ new Date());
		}
		return "editMember";
	}//
	@RequestMapping(value = "delete.do", 
			method = {RequestMethod.GET,RequestMethod.POST})
	public String delete(@ModelAttribute String user_id, Model model) throws Exception {
		logger.debug("Welcome UserController delete------------------! "+ new Date());
		try {
			iUserService.deleteUser(user_id);
			model.addAttribute("stat", "회원삭제 성공");
			model.addAttribute("msg", "삭제에 성공하였습니다. ");
			model.addAttribute("nurl","/index.jsp");
		}catch(Exception e){
			logger.debug("Welcome UserController delete fail------------------! "+ new Date());
			model.addAttribute("stat", "회원삭제 성공");
			model.addAttribute("msg", "삭제에 성공하였습니다. ");
			model.addAttribute("nurl","/logout.do");
		}
		return "success";
	}//
	
	@RequestMapping(value = "update.do", 
			method = {RequestMethod.GET,RequestMethod.POST})
	public String update(@ModelAttribute UserDto userdto, Model model, HttpSession session) throws Exception {
		logger.debug("Welcome UserController update------------------! "+ new Date());
		try {
			iUserService.updateUser(userdto);
			UserDto newUser = iUserService.findUserById(userdto.getUser_id());
			session.setAttribute("login", newUser);
			model.addAttribute("stat", "회원정보 수정 성공");
			model.addAttribute("msg", "수정에 성공하였습니다. ");
			model.addAttribute("nurl","/index.jsp");
		}catch(Exception e){
			logger.debug("Welcome UserController update fail------------------! "+ new Date());
			model.addAttribute("stat", "회원정보 수정 성공");
			model.addAttribute("msg", "수정에 성공하였습니다. ");
			model.addAttribute("nurl","/logout.do");
		}
		return "main";
	}//
}
