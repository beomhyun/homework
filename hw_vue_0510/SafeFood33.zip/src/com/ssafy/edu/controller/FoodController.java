package com.ssafy.edu.controller;

import java.util.Date;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ssafy.edu.service.IFoodDetailService;
import com.ssafy.edu.service.IFoodinfoService;

@Controller
public class FoodController {
	private static final Logger logger = LoggerFactory.getLogger(FoodController.class);
	@Autowired
	private IFoodinfoService iFoodinfoService;
	@Autowired
	private IFoodDetailService iFoodDetailService;
	
	@RequestMapping(value = "foodinfolist.do", method = RequestMethod.GET)
	public String foodinfolist(Model model) throws Exception{
		logger.debug("foodinfolist!"+new Date());
		model.addAttribute("foodinfos",iFoodinfoService.findAllFoods());
		return "productindex";
	}
	@RequestMapping(value = "fooddetail.do",method = {RequestMethod.GET,RequestMethod.POST})
	public String fooddetail(int food_code,Model model)throws Exception{
		logger.debug("fooddetail!"+new Date());
		model.addAttribute("foodinfo",iFoodinfoService.findFoodInfoById(food_code));
		model.addAttribute("fooddetail",iFoodDetailService.findDetailByInt(food_code));
		//model.addAttribute("allergy",iFoodinfoService.Allergy(food_code));
		return "productdetail";
	}
	@RequestMapping(value = "search.do",method = {RequestMethod.GET,RequestMethod.POST})
	public String search(String s_category,String s_keyword,Model model) throws Exception{
		logger.debug("search!"+new Date());
		HashMap<String, String> map = new HashMap<>();
		map.put("s_category", s_category);
		map.put("s_keyword",s_keyword);
		model.addAttribute("",iFoodinfoService.searchFood(map));
		return "productindex";
	}
}
