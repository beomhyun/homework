package com.ssafy.edu.vue.dto;

import java.io.Serializable;
import java.util.List;
//com.ssafy.edu.vue.dto.EmployeeDto
public class PageEmpDto implements Serializable {
	
	private int curpage =0;
	private int perpage =10;
	private int startpage =0;
	private int totaalpage =0;
	private int totalline =0;
	private List<EmployeeDto> emps;
	
	public List<EmployeeDto> getEmps() {
		return emps;
	}
	public void setEmps(List<EmployeeDto> emps) {
		this.emps = emps;
	}
	public int getTotalline() {
		return totalline;
	}
	public void setTotalline(int totalline) {
		this.totalline = totalline;
	}
	public PageEmpDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PageEmpDto(int curpage, int perpage, int startpage, int totaalpage) {
		super();
		this.curpage = curpage;
		this.perpage = perpage;
		this.startpage = startpage;
		this.totaalpage = totaalpage;
	}
	@Override
	public String toString() {
		return "PageEmpDto [curpage=" + curpage + ", perpage=" + perpage + ", startpage=" + startpage + ", totaalpage="
				+ totaalpage + "]";
	}
	public int getCurpage() {
		return curpage;
	}
	public void setCurpage(int curpage) {
		this.curpage = curpage;
	}
	public int getPerpage() {
		return perpage;
	}
	public void setPerpage(int perpage) {
		this.perpage = perpage;
	}
	public int getStartpage() {
		this.startpage = (this.curpage-1)*perpage;
		return startpage;
	}
	public void setStartpage(int startpage) {
		this.startpage = startpage;
	}
	public int getTotaalpage() {
		this.totaalpage = (int)Math.ceil(1.0*this.totalline/this.perpage);
		return totaalpage;
	}
	public void setTotaalpage(int totaalpage) {
		this.totaalpage = totaalpage;
	}
}
