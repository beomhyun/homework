package com.ssafy.edu.vue.dto;
//com.ssafy.edu.vue.dto.QnaBoardDto
public class QnaBoardDto {
	private int board_id;
	private String board_title;
	private String board_writer;
	private String board_writedate;
	private String board_content;
	private int board_readcount;
	private int board_groupid = 0;
	
	public QnaBoardDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public QnaBoardDto(int board_id, String board_title, String board_writer, String board_writedate,
			String board_content, int board_readcount, int board_groupid) {
		super();
		this.board_id = board_id;
		this.board_title = board_title;
		this.board_writer = board_writer;
		this.board_writedate = board_writedate;
		this.board_content = board_content;
		this.board_readcount = board_readcount;
		this.board_groupid = board_groupid;
	}
	public QnaBoardDto(String board_title, String board_writer, String board_writedate,
			String board_content, int board_readcount) {
		super();
		this.board_id = 0;
		this.board_title = board_title;
		this.board_writer = board_writer;
		this.board_writedate = board_writedate;
		this.board_content = board_content;
		this.board_readcount = board_readcount;
		this.board_groupid = 0;
	}
	@Override
	public String toString() {
		return "QnaBoardDto [board_id=" + board_id + ", board_title=" + board_title + ", board_writer=" + board_writer
				+ ", board_writedate=" + board_writedate + ", board_content=" + board_content + ", board_readcount="
				+ board_readcount + ", board_groupid=" + board_groupid + "]";
	}
	public int getBoard_id() {
		return board_id;
	}
	public void setBoard_id(int board_id) {
		this.board_id = board_id;
	}
	public String getBoard_title() {
		return board_title;
	}
	public void setBoard_title(String board_title) {
		this.board_title = board_title;
	}
	public String getBoard_writer() {
		return board_writer;
	}
	public void setBoard_writer(String board_writer) {
		this.board_writer = board_writer;
	}
	public String getBoard_writedate() {
		return board_writedate;
	}
	public void setBoard_writedate(String board_writedate) {
		this.board_writedate = board_writedate;
	}
	public String getBoard_content() {
		return board_content;
	}
	public void setBoard_content(String board_content) {
		this.board_content = board_content;
	}
	public int getBoard_readcount() {
		return board_readcount;
	}
	public void setBoard_readcount(int board_readcount) {
		this.board_readcount = board_readcount;
	}
	public int getBoard_groupid() {
		return board_groupid;
	}
	public void setBoard_groupid(int board_groupid) {
		this.board_groupid = board_groupid;
	}
	
}
