package com.ssafy.edu.vue.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.edu.vue.dto.DepCountDto;
import com.ssafy.edu.vue.dto.DepartmentDto;
import com.ssafy.edu.vue.dto.EmployeeDto;
import com.ssafy.edu.vue.dto.MapDto;
import com.ssafy.edu.vue.dto.PageEmpDto;
import com.ssafy.edu.vue.dto.QnaBoardDto;
import com.ssafy.edu.vue.help.BoolResult;
import com.ssafy.edu.vue.help.NumberResult;
import com.ssafy.edu.vue.service.EmployeeService;
import com.ssafy.edu.vue.service.IQnaBoardService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

//http://localhost:8197/humans/swagger-ui.html
@CrossOrigin(origins = {"*"}, maxAge = 6000)
@RestController
@RequestMapping("/api")
@Api(value="SSAFY", description="SSAFY Resouces Management 2019")
public class QnaBoardController {
	
	public static final Logger logger = LoggerFactory.getLogger(QnaBoardController.class);
	
	@Autowired
	private IQnaBoardService  qnaboardservice; 


    @ApiOperation(value = "모든 게시글의 정보를 반환한다.", response = List.class)
	@RequestMapping(value = "/findAllQnaBoards", method = RequestMethod.GET)
	public ResponseEntity<List<QnaBoardDto>> findAllQnaBoards() throws Exception {
		logger.info("1-------------findAllEmployees-----------------------------"+new Date());
		List<QnaBoardDto> boards = qnaboardservice.findAllQnaBoards();
		if (boards.isEmpty()) {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<QnaBoardDto>>(boards, HttpStatus.OK);
	}
    
    
    @ApiOperation(value = "글 등록.", response = List.class)
   	@RequestMapping(value = "/addQnaBoard", method = RequestMethod.POST)
   	public void addQnaBoard(@RequestBody QnaBoardDto dto) throws Exception {
   		logger.info("1-------------addQnaBoard-----------------------------"+new Date());
   		qnaboardservice.addQnaBoard(dto);
   	}
    
    @ApiOperation(value = "글 수정.", response = List.class)
   	@RequestMapping(value = "/updateQnaBoard", method = RequestMethod.POST)
   	public void updateQnaBoard(@RequestBody QnaBoardDto dto) throws Exception {
   		logger.info("1-------------updateQnaBoard-----------------------------"+new Date());
   		qnaboardservice.updateQnaBoard(dto);
   	}
    
    @ApiOperation(value = "글 삭제.", response = List.class)
   	@RequestMapping(value = "/deleteQnaBoard/{board_id}", method = RequestMethod.POST)
   	public void deleteQnaBoard(@PathVariable int board_id) throws Exception {
   		logger.info("1-------------deleteQnaBoard-----------------------------"+new Date());
   		qnaboardservice.deleteQnaBoard(board_id);
   	}
    
    @ApiOperation(value = "게시글 검색.", response = List.class)
	@RequestMapping(value = "/searchQnaBoards", method = RequestMethod.POST)
	public ResponseEntity<List<QnaBoardDto>> searchQnaBoards(@RequestBody MapDto dto) throws Exception {
		logger.info("1-------------searchQnaBoards-----------------------------"+new Date());
		
		List<QnaBoardDto> boards = qnaboardservice.searchQnaBoards(dto);
		if (boards.isEmpty()) {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}	
		return new ResponseEntity<List<QnaBoardDto>>(boards, HttpStatus.OK);
	}
    @ApiOperation(value = "조회수 증가.", response = List.class)
   	@RequestMapping(value = "/readcount/{board_id}", method = RequestMethod.GET)
   	public void readcount(@PathVariable int board_id) throws Exception {
   		logger.info("1-------------updateQnaBoard-----------------------------"+new Date());
   		qnaboardservice.readcount(board_id);
   	}
    
    @ApiOperation(value = "작성된 마지막 글 번호", response = List.class)
   	@RequestMapping(value = "/findAfterAdd", method = RequestMethod.GET)
   	public int findAfterAdd() throws Exception {
   		logger.info("1-------------findAfterAdd-----------------------------"+new Date());
   		return qnaboardservice.findAfterAdd()+1	;
   	}
    
    @ApiOperation(value = "상세 글", response = List.class)
	@RequestMapping(value = "/detailQnaBoard/{board_id}", method = RequestMethod.GET)
	public ResponseEntity<QnaBoardDto> detailQnaBoard(@PathVariable int board_id) throws Exception {
		logger.info("1-------------detailQnaBoard-----------------------------"+new Date());
		QnaBoardDto board = qnaboardservice.detailQnaBoard(board_id);
		if (board==null) {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<QnaBoardDto>(board, HttpStatus.OK);
	}
    
}
