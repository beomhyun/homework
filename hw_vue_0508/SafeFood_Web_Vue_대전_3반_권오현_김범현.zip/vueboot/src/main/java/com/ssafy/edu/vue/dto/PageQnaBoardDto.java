package com.ssafy.edu.vue.dto;
//com.ssafy.edu.vue.dto.PageQnaBoardDto
import java.io.Serializable;
import java.util.List;

public class PageQnaBoardDto implements Serializable{
   
   private int curpage = 0;
   private int perpage = 0;
   private int startpage = 0;
   private int totalpage = 0;
   private int totalline = 0;
   
   private List<QnaBoardDto> qnaboards;

public PageQnaBoardDto(int curpage, int perpage, int startpage, int totalpage, int totalline,
		List<QnaBoardDto> qnaboards) {
	super();
	this.curpage = curpage;
	this.perpage = perpage;
	this.startpage = startpage;
	this.totalpage = totalpage;
	this.totalline = totalline;
	this.qnaboards = qnaboards;
}

public int getCurpage() {
	return curpage;
}

public void setCurpage(int curpage) {
	this.curpage = curpage;
}

public int getPerpage() {
	return perpage;
}

public void setPerpage(int perpage) {
	this.perpage = perpage;
}

public int getStartpage() {
	this.startpage = (this.curpage-1)*perpage;
	return startpage;
}

public void setStartpage(int startpage) {
	this.startpage = startpage;
}

public int getTotalpage() {
	this.totalpage = (int)Math.ceil(1.0*this.totalline/this.perpage);
	return totalpage;
}

public void setTotalpage(int totalpage) {
	this.totalpage = totalpage;
}

public int getTotalline() {
	return totalline;
}

public void setTotalline(int totalline) {
	this.totalline = totalline;
}

public List<QnaBoardDto> getQnaboards() {
	return qnaboards;
}

public void setQnaboards(List<QnaBoardDto> qnaboards) {
	this.qnaboards = qnaboards;
}

@Override
public String toString() {
	return "PageQnaBoardDto [curpage=" + curpage + ", perpage=" + perpage + ", startpage=" + startpage + ", totalpage="
			+ totalpage + ", totalline=" + totalline + ", qnaboards=" + qnaboards + "]";
}

public PageQnaBoardDto() {
	super();
	// TODO Auto-generated constructor stub
}

   
   
}