package com.ssafy.edu.vue.dto;

public class MapDto {
	private String s_category;
	private String s_keyword;
	public MapDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MapDto(String s_category, String s_keyword) {
		super();
		this.s_category = s_category;
		this.s_keyword = s_keyword;
	}
	@Override
	public String toString() {
		return "MapDto [s_category=" + s_category + ", s_keyword=" + s_keyword + "]";
	}
	public String getS_category() {
		return s_category;
	}
	public void setS_category(String s_category) {
		this.s_category = s_category;
	}
	public String getS_keyword() {
		return s_keyword;
	}
	public void setS_keyword(String s_keyword) {
		this.s_keyword = s_keyword;
	}

}
