package com.ssafy.edu.vue.dao;

import java.util.HashMap;
import java.util.List;

import com.ssafy.edu.vue.dto.MapDto;
import com.ssafy.edu.vue.dto.PageQnaBoardDto;
import com.ssafy.edu.vue.dto.QnaBoardDto;

public interface IQnaBoardDao {
	public void addQnaBoard(QnaBoardDto dto) throws Exception;
	public void updateQnaBoard(QnaBoardDto dto) throws Exception;
	public void deleteQnaBoard(int boardid) throws Exception;
	public List<QnaBoardDto> findAllQnaBoards() throws Exception;
	public List<QnaBoardDto> searchQnaBoards(MapDto dto) throws Exception;
	public QnaBoardDto detailQnaBoard(int boardid) throws Exception;
	public int findAfterAdd() throws Exception;
	public void readcount(int boardid) throws Exception;
	public PageQnaBoardDto findAllQnaBoardsByPage() throws Exception;
	public PageQnaBoardDto searchQnaBoardsByPage(HashMap<String ,String> searchmap) throws Exception;
	
}
