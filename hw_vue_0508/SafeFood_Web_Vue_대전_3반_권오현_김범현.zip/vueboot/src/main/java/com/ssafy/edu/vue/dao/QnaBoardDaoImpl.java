package com.ssafy.edu.vue.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.edu.vue.dto.MapDto;
import com.ssafy.edu.vue.dto.PageQnaBoardDto;
import com.ssafy.edu.vue.dto.QnaBoardDto;
@Repository
public class QnaBoardDaoImpl implements IQnaBoardDao {

	private String ns = "com.ssafy.edu.vue.dao.QnaBoardDao.";
	
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public void addQnaBoard(QnaBoardDto dto) throws Exception {
		sqlSession.insert(ns+"addQnaBoard",dto);
	}

	@Override
	public void updateQnaBoard(QnaBoardDto dto) throws Exception {
		sqlSession.update(ns+"updateQnaBoard",dto);
	}

	@Override
	public void deleteQnaBoard(int boardid) throws Exception {
		sqlSession.delete(ns+"deleteQnaBoard",boardid);
	}

	@Override
	public List<QnaBoardDto> findAllQnaBoards() throws Exception {
		return sqlSession.selectList(ns+"findAllQnaBoards");
	}
	
	@Override
	public QnaBoardDto detailQnaBoard(int board_id) throws Exception {
		return sqlSession.selectOne(ns+"detailQnaBoard",board_id);
	}

	@Override
	public int findAfterAdd() throws Exception {
		return sqlSession.selectOne(ns+"findAfterAdd");
	}

	@Override
	public void readcount(int boardid) throws Exception {
		sqlSession.update(ns+"readcount",boardid);
	}

	
	@Override
	public List<QnaBoardDto> searchQnaBoards(MapDto dto) throws Exception {
		return sqlSession.selectList(ns+"searchQnaBoards",dto);
	}
	
	@Override
	public PageQnaBoardDto findAllQnaBoardsByPage() throws Exception {
		return null;
	}

	@Override
	public PageQnaBoardDto searchQnaBoardsByPage(HashMap<String, String> searchmap) throws Exception {
		return null;
	}
}
