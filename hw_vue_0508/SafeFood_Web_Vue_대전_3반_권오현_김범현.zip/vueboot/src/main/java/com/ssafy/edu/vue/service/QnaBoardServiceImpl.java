package com.ssafy.edu.vue.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.edu.vue.dao.IQnaBoardDao;
import com.ssafy.edu.vue.dto.MapDto;
import com.ssafy.edu.vue.dto.PageQnaBoardDto;
import com.ssafy.edu.vue.dto.QnaBoardDto;
@Service
public class QnaBoardServiceImpl implements IQnaBoardService {
	
	@Autowired
	private IQnaBoardDao iqnaboarddao;
	
	@Override
	@Transactional
	public void addQnaBoard(QnaBoardDto dto) throws Exception {
		dto.setBoard_id(iqnaboarddao.findAfterAdd()+1);
		if(dto.getBoard_groupid() == 0) dto.setBoard_groupid(iqnaboarddao.findAfterAdd()+1);
		iqnaboarddao.addQnaBoard(dto);
	}

	@Override
	@Transactional
	public void updateQnaBoard(QnaBoardDto dto) throws Exception {
		iqnaboarddao.updateQnaBoard(dto);
	}

	@Override
	@Transactional
	public void deleteQnaBoard(int boardid) throws Exception {
		iqnaboarddao.deleteQnaBoard(boardid);
	}

	@Override
	@Transactional(readOnly=true)
	public List<QnaBoardDto> findAllQnaBoards() throws Exception {
		return iqnaboarddao.findAllQnaBoards();
	}

	@Override
	@Transactional(readOnly=true)
	public List<QnaBoardDto> searchQnaBoards(MapDto dto) throws Exception {
		return iqnaboarddao.searchQnaBoards(dto);
	}

	@Override
	@Transactional(readOnly=true)
	public QnaBoardDto detailQnaBoard(int boardid) throws Exception {
		return iqnaboarddao.detailQnaBoard(boardid);
	}

	@Override
	@Transactional(readOnly=true)
	public int findAfterAdd() throws Exception {
		return iqnaboarddao.findAfterAdd();
	}

	@Override
	@Transactional
	public void readcount(int boardid) throws Exception {
		iqnaboarddao.readcount(boardid);
	}

	@Override
	@Transactional(readOnly=true)
	public PageQnaBoardDto findAllQnaBoardsByPage() throws Exception {
		return null;
	}

	@Override
	@Transactional(readOnly=true)
	public PageQnaBoardDto searchQnaBoardsByPage(HashMap<String, String> searchmap) throws Exception {
		return null;
	}

}
